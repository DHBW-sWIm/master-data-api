<?php

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External Web Service Template
 *
 * @package    localwstemplate
 * @copyright  2011 Moodle Pty Ltd (http://moodle.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once($CFG->libdir . "/externallib.php");

class local_wstemplate_external extends external_api {

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function hello_world_parameters() {
        return new external_function_parameters(
                array('welcomemessage' => new external_value(PARAM_TEXT, 'The welcome message. By default it is "Hello world,"', VALUE_DEFAULT, 'Hello world, '))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function hello_world($welcomemessage = 'Hello world, ') {
        global $USER;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::hello_world_parameters(),
                array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);

        //Capability checking
        //OPTIONAL but in most web service it should present
        if (!has_capability('moodle/user:viewdetails', $context)) {
            throw new moodle_exception('cannotviewprofile');
        }

        return $params['welcomemessage'] . $USER->firstname ;;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function hello_world_returns() {
        return new external_value(PARAM_TEXT, 'The welcome message + user first name');
    }

    public static function get_moodle_logfile_parameters() {
        return new external_function_parameters(
            array('checkpoint' => new external_value(PARAM_TEXT, 'last Check point', VALUE_DEFAULT, ''))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_moodle_logfile($checkpoint) {
        global $USER;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_moodle_logfile_parameters(),
                array('checkpoint' => $checkpoint));
        //open the log file to read all lines after the last chech point 
        $myfile = fopen("C:\\xampp\\htdocs\\moodle\\local\\wstemplate\\moodle_log.txt", "r");
        $arr=[];
        //Use Reg. Exp. to find the the check point 
        $pattern = '/CHECKPOINT = '. $checkpoint .'/i';
        $temp = false;
        $linee = fgets($myfile);
        while($linee) {
            if( preg_match($pattern, $linee)){
                $temp = true;
                $linee = fgets($myfile);
            }
            if ($temp){array_push($arr,$linee);}
            $linee = fgets($myfile);
        }
        //Add a new check point if there were new added lines after the last check point
        if ($arr[0]){
            $newcp = $checkpoint + 1;
            $newline = "[". date("d.m.Y H:i:s",time()). "] CHECKPOINT = " . $newcp  ;
            self::write_moodle_logfile($newline);
        }
        
        return  $arr ;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_moodle_logfile_returns() {

        return new external_multiple_structure(
            
             new external_value(PARAM_TEXT, 'Line of the log file'));
    }

    public static function write_moodle_logfile_parameters() {
        return new external_function_parameters(
            array('message' => new external_value(PARAM_TEXT, 'Document the DML statement on Company table "Company calssification" ', VALUE_DEFAULT, ' Empty'))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function write_moodle_logfile($newline = 'Default Value') {

        global $USER;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::write_moodle_logfile_parameters(),
                array('message' => $newline));

        // Returned value
        $returned_value = "";
        //$newline .= "\r\n";


        // Function
        $logfile = fopen("C:\\xampp\\htdocs\\moodle\\local\\wstemplate\\moodle_log.txt", "a+");
        // exclusive lock
        if (flock($logfile,LOCK_EX)) {
            fwrite($logfile,"\r\n");
            fwrite($logfile,$newline);
            //fflush($logfile);
        // release lock
            flock($logfile,LOCK_UN);
        // return value 
            $returned_value = "Successful";
        } else {
        // Wait 3 second then try agian
            $returned_value = "File is locked retry after 3 Sec";
            sleep(3);
            if (flock($logfile,LOCK_EX)) {
                fwrite($logfile,$newline);
                fflush($logfile);
            // release lock
                flock($logfile,LOCK_UN);
                $returned_value .= "\t Successful";
            } else {
                $returned_value .= "\t Error locking file!";
                }
            }

        fclose($logfile);

    
    return $returned_value;
}

/**
 * Returns description of method result value
 * @return external_description
 */
public static function write_moodle_logfile_returns() {
    return new external_value(PARAM_TEXT, 'Status of the writing function');
}


 /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function inser_new_company_parameters() {
        return new external_function_parameters(
                array('companyname' => new external_value(PARAM_TEXT, 'The name of the new company', VALUE_DEFAULT, ''))
        );
    }

    /**
     * Returns The response of the inseret statement
     * @return string The response of the inseret statement
     */
    public static function inser_new_company($companyname = '') {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::inser_new_company_parameters(),
                array('companyname' => $companyname));

        //Check if the company exists 
        $status = $DB->get_record_select('dg_company', 'company_name = ?', array($companyname));
        
        
        if ($status) {
            $response_var = "The company already exists. ";
            
        } else {
            $response_var = $DB->insert_record("dg_company", array('company_name' => $companyname, 'classification' => 'B'));
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function inser_new_company_returns() {
        return new external_value(PARAM_TEXT, 'The response of the inseret statement');
    }

/**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function update_company_parameters() {
        return new external_function_parameters(
                array('company_name' => new external_value(PARAM_TEXT, 'company name', VALUE_DEFAULT, ''),
                'id' => new external_value(PARAM_TEXT, 'company id', VALUE_DEFAULT, ''),
                'classification' => new external_value(PARAM_TEXT, 'company classification', VALUE_DEFAULT, '') )
        );
    }

    /**
     * Returns The response of the update statement
     * @return string The response of the update statement
     */
    public static function update_company($companyid, $companyname, $classification) {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_company_parameters(),
                array('company_name' => $companyname, 
                'id' => $companyid,
                'classification' => $classification));

        //Check if the company exists 
        $status = $DB->get_record_select('dg_company', 'id = ?', array($companyid));
        
        
        if ($status) {
            
            $response_var = $DB->update_record('dg_company', $params);
            
        } else {
            $response_var = "The company does not exist. ";
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function update_company_returns() {
        return new external_value(PARAM_TEXT, 'The response of the update statement');
    }
    

/**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function delete_company_parameters() {
        return new external_function_parameters(
                array('company_name' => new external_value(PARAM_TEXT, 'company name', VALUE_DEFAULT, ''),
                'id' => new external_value(PARAM_TEXT, 'company id', VALUE_DEFAULT, ''),
                'classification' => new external_value(PARAM_TEXT, 'company classification', VALUE_DEFAULT, '') )
        );
    }

    /**
     * Returns The response of the delete statement
     * @return string The response of the delete statement
     */
    public static function delete_company($companyid, $companyname, $classification) {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_company_parameters(),
                array('company_name' => $companyname, 
                'id' => $companyid,
                'classification' => $classification));

        //Check if the company exists 
        $status = $DB->get_record_select('dg_company', 'company_name = ?', array($companyname));
        
        
        if ($status) {
            
            $response_var = $DB->delete_records('dg_company',json_decode(json_encode($status), true));
            
        } else {
            $response_var = "The company does not exist. ";
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function delete_company_returns() {
        return new external_value(PARAM_TEXT, 'The response of the delete statement');
    }
    
     /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function insert_new_company_rep_parameters() {
        return new external_function_parameters(
                array('first_name' => new external_value(PARAM_TEXT, 'First name', VALUE_DEFAULT, ''),
                'last_name' => new external_value(PARAM_TEXT, 'Last name', VALUE_DEFAULT, ''),
                'email' => new external_value(PARAM_TEXT, 'Email', VALUE_DEFAULT, ''),
                'phone' => new external_value(PARAM_TEXT, 'Phone ', VALUE_DEFAULT, ''),
                'compnay_id' => new external_value(PARAM_TEXT, 'Compnay Id', VALUE_DEFAULT, ''),
                'mdl_user_id' => new external_value(PARAM_TEXT, 'Moodle User ID', VALUE_DEFAULT, ''))
        );
    }

    /**
     * Returns The response of the inseret statement
     * @return string The response of the inseret statement
     */
    public static function insert_new_company_rep($fname, $lname, $email, $phone, $company_id, $mdl_usr_id) {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::insert_new_company_rep_parameters(),
                array('first_name' => $fname,
                      'last_name' => $lname,
                      'email' => $email,
                      'phone' => $phone,
                      'compnay_id' =>  $company_id,
                      'mdl_user_id' => $mdl_usr_id            
            ));

        //Check if the company exists 
        $status = $DB->get_record_select('dg_company_representative', 'first_name = ? and last_name = ?', array($fname,$lname));
        
        
        if ($status) {
            $response_var = "The company Rep already exists. ";
            
        } else {
            $response_var = $DB->insert_record("dg_company_representative", $params);
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function insert_new_company_rep_returns() {
        return new external_value(PARAM_TEXT, 'The response of the inseret statement');
    }

/**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function update_company_rep_parameters() {
        return new external_function_parameters(
            array('old_fname' => new external_value(PARAM_TEXT, 'Id ', VALUE_DEFAULT, ''),
            'old_lname' => new external_value(PARAM_TEXT, 'Id ', VALUE_DEFAULT, ''),
            'first_name' => new external_value(PARAM_TEXT, 'First name', VALUE_DEFAULT, ''),
            'last_name' => new external_value(PARAM_TEXT, 'Last name', VALUE_DEFAULT, ''),
            'email' => new external_value(PARAM_TEXT, 'Email', VALUE_DEFAULT, ''),
            'phone' => new external_value(PARAM_TEXT, 'Phone ', VALUE_DEFAULT, ''),
            'compnay_id' => new external_value(PARAM_TEXT, 'Compnay Id', VALUE_DEFAULT, ''),
            'mdl_user_id' => new external_value(PARAM_TEXT, 'Moodle User ID', VALUE_DEFAULT, ''))
    );
    }

    /**
     * Returns The response of the update statement
     * @return string The response of the update statement
     */
    public static function update_company_rep($old_fname,$old_lname,$fname, $lname, $email, $phone, $company_id, $mdl_usr_id) {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_company_rep_parameters(),
                array('old_fname' => $old_fname,
                      'old_lname' => $old_lname,
                      'first_name' => $fname,
                      'last_name' => $lname,
                      'email' => $email,
                      'phone' => $phone,
                      'compnay_id' =>  $company_id,
                      'mdl_user_id' => $mdl_usr_id            
            ));

        //Check if the company exists and get the id 
        $status = $DB->get_record_select('dg_company_representative', 'first_name = ? and last_name = ?', array($old_fname,$old_lname));
        
        
        if ($status) {


             $params['id'] = $status->id;
             $params['mdl_user_id'] = $status->mdl_user_id;
            $response_var = $DB->update_record('dg_company_representative', $params);
            
        } else {
            $response_var = "The company does not exist. ";
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function update_company_rep_returns() {
        return new external_value(PARAM_TEXT, 'The response of the update statement');
    }
    

/**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function delete_company_rep_parameters() {
        return new external_function_parameters(
            array(
            'first_name' => new external_value(PARAM_TEXT, 'First name', VALUE_DEFAULT, ''),
            'last_name' => new external_value(PARAM_TEXT, 'Last name', VALUE_DEFAULT, ''),
            'email' => new external_value(PARAM_TEXT, 'Email', VALUE_DEFAULT, ''),
            'phone' => new external_value(PARAM_TEXT, 'Phone ', VALUE_DEFAULT, ''),
            'compnay_id' => new external_value(PARAM_TEXT, 'Compnay Id', VALUE_DEFAULT, ''),
            'mdl_user_id' => new external_value(PARAM_TEXT, 'Moodle User ID', VALUE_DEFAULT, ''))
    );
    }

    /**
     * Returns The response of the delete statement
     * @return string The response of the delete statement
     */
    public static function delete_company_rep($fname, $lname, $email, $phone, $company_id) {
        global $USER, $DB;
        $response_var = '';

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_company_rep_parameters(),
                array('first_name' => $fname,
                      'last_name' => $lname,
                      'email' => $email,
                      'phone' => $phone,
                      'compnay_id' =>  $company_id
                      //'mdl_user_id' => $mdl_usr_id            
            ));

        //Check if the company exists and get the ID
        $status = $DB->get_record_select('dg_company_representative', 'compnay_id = ? and last_name = ? and first_name = ?', array($company_id,$lname,$fname));
        
        
        if ($status) {
            
            $response_var = $DB->delete_records('dg_company_representative', json_decode(json_encode($status), true));
            
        } else {
            $response_var = "The company does not exist. ";
                }
        // 

        return $response_var;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function delete_company_rep_returns() {
        return new external_value(PARAM_TEXT, 'The response of the delete statement');
    }
}
